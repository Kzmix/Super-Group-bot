from __future__ import annotations

import asyncio
import logging
import signal
from contextlib import asynccontextmanager

from telethon import events
from sqlalchemy.ext.asyncio import AsyncSession

from .config import Settings, setup_logging
from .client import build_client
from .db.base import make_engine, make_session_factory, Base
from .db.repo import Repo
from .db.models import GroupConfig, GateMode
from .handlers.moderation import process_message
from .handlers.gate import enforce_gate
from .handlers.welcome import on_user_join
from .handlers.commands import COMMAND_HANDLERS
from .services.security import bot_has_perms

# Optional aiohttp server
from aiohttp import web

log = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan():
    cfg = Settings()
    setup_logging(cfg.LOG_LEVEL)

    engine = make_engine(cfg)
    Session = make_session_factory(engine)

    # ensure DB exists (alembic will handle migrations; here is lightweight ping)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    client = await build_client(cfg)

    app_state = {"cfg": cfg, "Session": Session, "client": client}
    try:
        yield app_state
    finally:
        await client.disconnect()
        await engine.dispose()


def parse_command(text: str) -> tuple[str | None, str]:
    if not text or not text.startswith("/"):
        return None, text
    cmd, *rest = text[1:].split(maxsplit=1)
    return cmd.lower(), rest[0] if rest else ""


async def run_bot(app_state):
    client = app_state["client"]
    cfg: Settings = app_state["cfg"]
    Session = app_state["Session"]

    @client.on(events.NewMessage(incoming=True))
    async def on_new_message(ev: events.NewMessage.Event):
        async with Session() as db:  # type: AsyncSession
            repo = Repo(db)

            if ev.is_private and ev.raw_text.strip().lower().startswith("/start"):
                args = ev.raw_text.strip().split(maxsplit=1)
                if len(args) > 1 and args[1].strip().lower() == "verify":
                    # try to re-verify last group(s) where gate is active; simple approach: send instruction
                    await ev.reply("Oke! Setelah join target, kirim pesan di grup untuk diproses ulang. 😊")
                else:
                    await ev.reply(
                        "Hai! Tambahkan aku ke grup kamu sebagai admin (hapus, restrict).\n"
                        "Perintah: /help\n"
                    )
                return

            # Group setup: create config
            if ev.is_group or ev.is_channel:
                gc = await repo.get_or_create_group(ev.chat_id)

                # Commands (from group or DM for import)
                if ev.raw_text and ev.raw_text.startswith("/"):
                    cmd, _ = parse_command(ev.raw_text)
                    if cmd in COMMAND_HANDLERS:
                        try:
                            await COMMAND_HANDLERS[cmd](ev, client, repo, cfg)  # type: ignore
                        except TypeError:
                            # handlers with fewer args
                            await COMMAND_HANDLERS[cmd](ev, repo)  # type: ignore
                        return

                # Gate enforcement (if not message from admin/bot itself)
                sender = await ev.get_sender()
                if sender and not sender.bot and (ev.is_group or ev.is_channel):
                    violated = await enforce_gate(
                        client, db, cfg, gc, ev.chat_id, sender.id, ev.id, sender.first_name or ""
                    )
                    if violated:
                        return

                # Anti-spam + forbidden
                if sender and not sender.bot:
                    await process_message(client, db, gc, ev.chat_id, sender.id, ev.message, cfg.SPAM_WINDOW_SECONDS)

    @client.on(events.ChatAction())
    async def on_action(ev: events.ChatAction.Event):
        if ev.user_joined or ev.user_added:
            async with Session() as db:
                repo = Repo(db)
                gc = await repo.get_or_create_group(ev.chat_id)
                if ev.user:
                    await on_user_join(client, db, gc, ev.chat_id, ev.user)

    log.info("Bot is running (long-polling).")
    await client.run_until_disconnected()


async def run_http(app_state):
    cfg: Settings = app_state["cfg"]
    if not cfg.WEBHOOK_SECRET:
        # optional server disabled; but we still expose healthcheck if BASE_URL present
        if not cfg.BASE_URL:
            return  # skip HTTP altogether
    app = web.Application()

    async def health(_):
        return web.json_response({"ok": True})

    async def webhook(request: web.Request):
        if request.match_info.get("secret") != (cfg.WEBHOOK_SECRET or ""):
            return web.Response(status=403, text="forbidden")
        try:
            payload = await request.json()
        except Exception:
            payload = {"note": "no json"}
        log.info("Webhook hit: %s", payload)
        return web.json_response({"ok": True})

    app.router.add_get("/health", health)
    if cfg.WEBHOOK_SECRET:
        app.router.add_post(f"/webhook/{{secret}}", webhook)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", 8080)
    await site.start()
    log.info("HTTP server started on :8080")
    # keep running
    while True:
        await asyncio.sleep(3600)


async def main():
    async with lifespan() as app_state:
        # Run bot and optional HTTP server concurrently
        await asyncio.gather(run_bot(app_state), run_http(app_state))


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass