from __future__ import annotations

import asyncio
import logging
from telethon import TelegramClient
from telethon.sessions import StringSession
from .config import Settings

log = logging.getLogger(__name__)


async def build_client(cfg: Settings) -> TelegramClient:
    """
    Create and start Telethon client.
    - Bot mode (recommended): needs API_ID/API_HASH + BOT_TOKEN
    - Userbot mode (optional): needs API_ID/API_HASH + SESSION_NAME (StringSession or file)
    """
    if not cfg.API_ID or not cfg.API_HASH:
        raise RuntimeError("API_ID & API_HASH wajib diisi (Telethon requirement).")

    if cfg.BOT_TOKEN:
        session = cfg.SESSION_NAME  # file-based session, harmless even for bot
        client = TelegramClient(session, cfg.API_ID, cfg.API_HASH)
        await client.start(bot_token=cfg.BOT_TOKEN)
        me = await client.get_me()
        log.info("Started in BOT mode as @%s (%s)", me.username, me.id)
    else:
        # Userbot mode
        # If SESSION_NAME looks like "1A2B...": treat as StringSession; else file session
        if cfg.SESSION_NAME.endswith(".session") or "/" in cfg.SESSION_NAME:
            session = cfg.SESSION_NAME
        else:
            session = StringSession(cfg.SESSION_NAME)
        client = TelegramClient(session, cfg.API_ID, cfg.API_HASH)
        await client.start()
        me = await client.get_me()
        log.info("Started in USERBOT mode as %s (%s)", me.username or me.first_name, me.id)

    return client