from __future__ import annotations

import logging
import math
import re
import time
from collections import deque, defaultdict
from typing import Deque, Dict, Tuple

from telethon import TelegramClient, events
from telethon.tl.functions.channels import EditBannedRequest
from telethon.tl.types import ChatBannedRights, Message

from sqlalchemy.ext.asyncio import AsyncSession

from ..db.repo import Repo
from ..db.models import GroupConfig
from ..services.logging_svc import log_action

log = logging.getLogger(__name__)

# In-memory per (chat_id, user_id) message timestamps to implement sliding window (7s)
_msg_windows: Dict[Tuple[int, int], Deque[float]] = defaultdict(lambda: deque(maxlen=50))

_url_re = re.compile(r"https?://\S+|t\.me/[A-Za-z0-9_]+", re.I)
_mention_re = re.compile(r"@\w+")
_promo_re = re.compile(r"(gratis|promo|diskon|klik\s+link|daftar\s+sekarang|bonus)", re.I)


def _caps_ratio(text: str) -> float:
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return 0.0
    caps = [c for c in letters if c.isupper()]
    return len(caps) / len(letters)


def _repetition_score(text: str) -> float:
    if not text:
        return 0.0
    # simple: longest repeated char streak over length
    streak = 1
    max_streak = 1
    last = None
    for c in text:
        if c == last:
            streak += 1
            max_streak = max(max_streak, streak)
        else:
            streak = 1
            last = c
    return max_streak / max(10, len(text))


def _calc_spam_score(text: str, window_cnt: int) -> int:
    score = 0
    if not text:
        return 0
    links = len(_url_re.findall(text))
    mentions = len(_mention_re.findall(text))
    length = len(text)
    caps = _caps_ratio(text)
    rep = _repetition_score(text)
    promo = 1 if _promo_re.search(text) else 0

    score += links * 2
    score += mentions
    score += int(caps > 0.7) * 2
    score += int(rep > 0.3) * 2
    score += promo * 3
    score += int(length > 400)
    score += max(0, window_cnt - 3)  # burst in window

    return score


async def apply_spam_action(client: TelegramClient, db: AsyncSession, group: GroupConfig, chat_id: int, user_id: int, msg: Message, score: int):
    action = (group.spam_action or "delete").lower()
    reason = f"spam_score={score}"

    # Always delete for visibility if possible
    try:
        await client.delete_messages(chat_id, [msg.id])
    except Exception:
        pass

    if action == "delete":
        await log_action(db, chat_id, user_id, "delete", reason, msg.id)
        return

    if action.startswith("mute:"):
        # parse duration like mute:10m
        from ..utils.parser import parse_duration
        dur = parse_duration(action.split(":", 1)[1])
        until = int(time.time() + dur.total_seconds())
        rights = ChatBannedRights(until_date=until, send_messages=True)
        try:
            await client(EditBannedRequest(chat_id, user_id, rights))
            await log_action(db, chat_id, user_id, "mute", reason, msg.id)
        except Exception as e:
            log.debug("mute failed: %s", e)
        return

    if action == "kick":
        rights = ChatBannedRights(until_date=None, view_messages=True)
        try:
            await client(EditBannedRequest(chat_id, user_id, rights))  # ban
            await log_action(db, chat_id, user_id, "kick", reason, msg.id)
            # unban shortly after for "temporary ban"
            rights2 = ChatBannedRights(until_date=0, view_messages=False)
            await client(EditBannedRequest(chat_id, user_id, rights2))
        except Exception as e:
            log.debug("kick failed: %s", e)


async def check_forbidden_and_act(client: TelegramClient, db: AsyncSession, group: GroupConfig, chat_id: int, user_id: int, msg: Message) -> bool:
    # Compile combined regex
    tokens = group.forbidden_raw or []
    if not tokens:
        return False

    parts = []
    for t in tokens:
        t = str(t)
        if len(t) >= 2 and t.startswith("/") and t.endswith("/"):
            # treat as regex (already)
            parts.append(f"(?:{t[1:-1]})")
        else:
            # escape literal word
            parts.append(re.escape(t))
    if not parts:
        return False

    combined = re.compile("|".join(parts), re.I)
    content = (msg.message or "") + " " + (getattr(msg, "raw_text", "") or "")
    if msg.media and hasattr(msg.media, "caption") and msg.media.caption:
        content += " " + msg.media.caption

    if combined.search(content or ""):
        # Delete and warn
        try:
            await client.delete_messages(chat_id, [msg.id])
        except Exception:
            pass
        hash_token = Repo.tiny_hash(combined.pattern)
        await log_action(db, chat_id, user_id, "delete", f"forbidden:{hash_token}", msg.id)
        try:
            await client.send_message(chat_id, f"Pesan dihapus (kata terlarang).", reply_to=msg.id)
        except Exception:
            pass
        return True
    return False


async def process_message(client: TelegramClient, db: AsyncSession, group: GroupConfig, chat_id: int, user_id: int, msg: Message, spam_window_s: int) -> None:
    # Forbidden first
    if await check_forbidden_and_act(client, db, group, chat_id, user_id, msg):
        return

    # Sliding window
    dq = _msg_windows[(chat_id, user_id)]
    now = time.time()
    dq.append(now)
    # count how many within window
    while dq and now - dq[0] > spam_window_s:
        dq.popleft()
    cnt = len(dq)

    text = msg.message or ""
    score = _calc_spam_score(text, cnt)
    if score >= group.spam_threshold:
        await apply_spam_action(client, db, group, chat_id, user_id, msg, score)