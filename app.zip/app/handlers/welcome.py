from __future__ import annotations

import logging
import time
from typing import Dict, Tuple

from telethon import TelegramClient, events
from telethon.tl.types import User

from sqlalchemy.ext.asyncio import AsyncSession

from ..db.repo import Repo
from ..db.models import GroupConfig

log = logging.getLogger(__name__)

# rate limit welcome per (chat_id) to avoid spam on mass-join
_last_welcome_ts: Dict[int, float] = {}


def render_template(tpl: str, user: User, rules_link: str | None, gate_target: str | None) -> str:
    first = user.first_name or "Teman"
    username = ("@" + user.username) if user.username else ""
    text = (tpl or "Selamat datang {first_name}!").format(
        first_name=first, username=username, rules_link=rules_link or "", gate_target=gate_target or ""
    )
    return text


async def on_user_join(client: TelegramClient, db: AsyncSession, group: GroupConfig, chat_id: int, user: User) -> None:
    if not group.welcome_enabled:
        return

    now = time.time()
    if _last_welcome_ts.get(chat_id, 0) + 5 > now:
        return  # throttle to avoid flood
    _last_welcome_ts[chat_id] = now

    text = render_template(group.welcome_template, user, None, group.gate_target)
    try:
        await client.send_message(chat_id, text)
    except Exception as e:
        log.debug("welcome failed: %s", e)