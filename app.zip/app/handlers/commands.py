from __future__ import annotations

import json
import logging
from io import BytesIO
from typing import Optional

from telethon import TelegramClient, events
from telethon.tl.functions.channels import EditBannedRequest
from telethon.tl.types import ChatBannedRights, Message

from sqlalchemy.ext.asyncio import AsyncSession

from ..db.repo import Repo
from ..db.models import GroupConfig, GateMode
from ..services.security import is_admin, bot_has_perms
from ..utils.parser import parse_duration, parse_spam_action
from ..config import Settings
from ..services.logging_svc import log_action

log = logging.getLogger(__name__)

HELP_TEXT = (
    "/help – ringkasan fitur\n"
    "/settings – tampilkan konfigurasi grup\n"
    "/gate off | /gate channel <@username|link> | /gate group <invite_link>\n"
    "/forbidden add <kata|/regex/> | /forbidden remove <kata|/regex/> | /forbidden list\n"
    "/spam threshold <angka> | /spam action <delete|mute:10m|kick>\n"
    "/mute <reply|@user> <durasi> – mute manual (admin)\n"
    "/kick <reply|@user> – kick manual (admin)\n"
    "/logs – 10 aksi terakhir\n"
    "/export – ekspor konfigurasi grup (JSON) via DM\n"
    "/import – impor konfigurasi (kirim file JSON di DM)\n"
    "/welcome on|off | /welcome template <teks> | /welcome preview\n"
)


async def cmd_help(ev: events.NewMessage.Event):
    await ev.reply(HELP_TEXT)


async def ensure_group(ev: events.NewMessage.Event, repo: Repo) -> GroupConfig:
    return await repo.get_or_create_group(ev.chat_id)


async def only_admin(ev: events.NewMessage.Event, client: TelegramClient, cfg: Settings) -> bool:
    if ev.is_private:
        return True
    return await is_admin(client, ev.chat_id, ev.sender_id)


def parse_args(text: str) -> list[str]:
    parts = text.strip().split()
    return parts[1:] if parts else []


async def cmd_settings(ev: events.NewMessage.Event, repo: Repo):
    gc = await repo.get_or_create_group(ev.chat_id)
    txt = (
        f"📘 *Settings grup*\n\n"
        f"Gate: {gc.gate_mode.value} {gc.gate_target or ''}\n"
        f"Spam threshold: {gc.spam_threshold}\n"
        f"Spam action: {gc.spam_action}\n"
        f"Forbidden: {len(gc.forbidden_raw or [])} entri\n"
        f"Welcome: {'on' if gc.welcome_enabled else 'off'}\n"
        f"Template: {gc.welcome_template[:120]}{'...' if len(gc.welcome_template)>120 else ''}\n"
    )
    await ev.reply(txt, parse_mode="md")


async def cmd_gate(ev: events.NewMessage.Event, client: TelegramClient, repo: Repo, cfg: Settings):
    if not await only_admin(ev, client, cfg):
        return await ev.reply("Perintah ini khusus admin.")
    args = parse_args(ev.raw_text)
    if not args:
        return await ev.reply("Gunakan: /gate off | /gate channel <@username|link> | /gate group <invite_link>")
    gc = await repo.get_or_create_group(ev.chat_id)
    if args[0].lower() == "off":
        gc.gate_mode = GateMode.off
        gc.gate_target = None
    elif args[0].lower() in {"channel", "group"}:
        if len(args) < 2:
            return await ev.reply("Sertakan target @username atau tautan undangan.")
        gc.gate_mode = GateMode[args[0].lower()]
        gc.gate_target = args[1]
    else:
        return await ev.reply("Argumen tidak dikenali.")
    await repo.save_group(gc)
    await ev.reply(f"Gate di-set: {gc.gate_mode.value} {gc.gate_target or ''}")


async def cmd_forbidden(ev: events.NewMessage.Event, client: TelegramClient, repo: Repo, cfg: Settings):
    if not await only_admin(ev, client, cfg):
        return await ev.reply("Perintah ini khusus admin.")
    args = parse_args(ev.raw_text)
    if not args:
        return await ev.reply("Gunakan: /forbidden add <kata|/regex/> | remove <kata|/regex/> | list")
    sub = args[0].lower()
    if sub == "add" and len(args) >= 2:
        token = " ".join(args[1:])
        items = await repo.add_forbidden(ev.chat_id, token)
        return await ev.reply(f"Ditambah. Total {len(items)} entri.")
    if sub == "remove" and len(args) >= 2:
        token = " ".join(args[1:])
        items = await repo.remove_forbidden(ev.chat_id, token)
        return await ev.reply(f"Dihapus. Total {len(items)} entri.")
    if sub == "list":
        gc = await repo.get_or_create_group(ev.chat_id)
        items = gc.forbidden_raw or []
        if not items:
            return await ev.reply("Daftar kosong.")
        preview = "\n".join(f"- {t}" for t in items[:50])
        return await ev.reply(f"Daftar kata terlarang ({len(items)}):\n{preview}")
    return await ev.reply("Argumen tidak dikenali.")


async def cmd_spam(ev: events.NewMessage.Event, client: TelegramClient, repo: Repo, cfg: Settings):
    if not await only_admin(ev, client, cfg):
        return await ev.reply("Perintah ini khusus admin.")
    args = parse_args(ev.raw_text)
    if not args:
        return await ev.reply("Gunakan: /spam threshold <angka> | /spam action <delete|mute:10m|kick>")
    gc = await repo.get_or_create_group(ev.chat_id)
    if args[0].lower() == "threshold" and len(args) >= 2:
        try:
            val = int(args[1])
        except ValueError:
            return await ev.reply("Masukkan angka.")
        gc.spam_threshold = val
        await repo.save_group(gc)
        return await ev.reply(f"Threshold di-set: {val}")
    if args[0].lower() == "action" and len(args) >= 2:
        try:
            p = parse_spam_action(" ".join(args[1:]))
        except Exception as e:
            return await ev.reply(str(e))
        gc.spam_action = p
        await repo.save_group(gc)
        return await ev.reply(f"Aksi spam di-set: {p}")
    return await ev.reply("Argumen tidak dikenali.")


async def _get_target_user(ev: events.NewMessage.Event) -> Optional[int]:
    if ev.is_reply:
        msg = await ev.get_reply_message()
        return msg.sender_id
    parts = ev.raw_text.split()
    if len(parts) >= 2 and parts[1].startswith("@"):
        try:
            user = await ev.client.get_entity(parts[1])
            return user.id
        except Exception:
            return None
    return None


async def cmd_mute(ev: events.NewMessage.Event, client: TelegramClient, repo: Repo, cfg: Settings):
    if not await only_admin(ev, client, cfg):
        return await ev.reply("Perintah ini khusus admin.")
    user_id = await _get_target_user(ev)
    if not user_id:
        return await ev.reply("Gunakan reply atau @username.")
    parts = ev.raw_text.split()
    if len(parts) < 3:
        return await ev.reply("Sertakan durasi, misal 10m.")
    try:
        dur = parse_duration(parts[2])
    except Exception as e:
        return await ev.reply(str(e))
    until = int(__import__("time").time() + dur.total_seconds())
    rights = ChatBannedRights(until_date=until, send_messages=True)
    try:
        await client(EditBannedRequest(ev.chat_id, user_id, rights))
        await log_action(repo.session, ev.chat_id, user_id, "mute", f"manual:{parts[2]}", None)
        await ev.reply("User dimute.")
    except Exception as e:
        await ev.reply(f"Gagal mute: {e}")


async def cmd_kick(ev: events.NewMessage.Event, client: TelegramClient, repo: Repo, cfg: Settings):
    if not await only_admin(ev, client, cfg):
        return await ev.reply("Perintah ini khusus admin.")
    user_id = await _get_target_user(ev)
    if not user_id:
        return await ev.reply("Gunakan reply atau @username.")
    rights = ChatBannedRights(until_date=None, view_messages=True)
    try:
        await client(EditBannedRequest(ev.chat_id, user_id, rights))
        await log_action(repo.session, ev.chat_id, user_id, "kick", "manual", None)
        # unban
        rights2 = ChatBannedRights(until_date=0, view_messages=False)
        await client(EditBannedRequest(ev.chat_id, user_id, rights2))
        await ev.reply("User di-kick.")
    except Exception as e:
        await ev.reply(f"Gagal kick: {e}")


async def cmd_logs(ev: events.NewMessage.Event, repo: Repo):
    rows = await repo.last_logs(ev.chat_id, 10)
    if not rows:
        return await ev.reply("Belum ada log.")
    lines = [f"- {r.created_at:%Y-%m-%d %H:%M:%S} | u={r.user_id} | {r.action} | {r.reason or ''}" for r in rows]
    await ev.reply("Aksi terakhir:\n" + "\n".join(lines))


async def cmd_export(ev: events.NewMessage.Event, client: TelegramClient, repo: Repo, cfg: Settings):
    if not await only_admin(ev, client, cfg):
        return await ev.reply("Perintah ini khusus admin.")
    gc = await repo.get_or_create_group(ev.chat_id)
    data = {
        "chat_id": gc.chat_id,
        "gate_mode": gc.gate_mode.value,
        "gate_target": gc.gate_target,
        "spam_threshold": gc.spam_threshold,
        "spam_action": gc.spam_action,
        "forbidden_raw": gc.forbidden_raw,
        "welcome_enabled": gc.welcome_enabled,
        "welcome_template": gc.welcome_template,
    }
    buf = BytesIO(json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"))
    buf.name = f"config_{gc.chat_id}.json"
    try:
        await client.send_file(ev.sender_id, buf, caption="Export konfigurasi grup.")
        await log_action(repo.session, ev.chat_id, ev.sender_id, "export", None, None)
        await ev.reply("Dikirim via DM.")
    except Exception:
        await ev.reply("Tidak bisa DM kamu. Pastikan DM terbuka.")


async def cmd_import(ev: events.NewMessage.Event, client: TelegramClient, repo: Repo, cfg: Settings):
    if not ev.is_private:
        return await ev.reply("Impor dilakukan di DM. Kirim file JSON di sini dengan caption /import.")
    if not ev.message.file:
        return await ev.reply("Kirim file JSON (hasil /export) dengan caption /import.")
    try:
        byts = await ev.message.download_media(bytes)
        data = json.loads(byts.decode("utf-8"))
        chat_id = int(data["chat_id"])
        gc = await repo.get_or_create_group(chat_id)
        gc.gate_mode = GateMode(data.get("gate_mode", "off"))
        gc.gate_target = data.get("gate_target")
        gc.spam_threshold = int(data.get("spam_threshold", 8))
        gc.spam_action = data.get("spam_action", "delete")
        gc.forbidden_raw = data.get("forbidden_raw", [])
        gc.welcome_enabled = bool(data.get("welcome_enabled", False))
        gc.welcome_template = data.get("welcome_template", "Selamat datang {first_name}!")
        await repo.save_group(gc)
        await log_action(repo.session, chat_id, ev.sender_id, "import", None, None)
        await ev.reply(f"Konfigurasi untuk chat {chat_id} diimpor.")
    except Exception as e:
        await ev.reply(f"Gagal impor: {e}")


async def cmd_welcome(ev: events.NewMessage.Event, client: TelegramClient, repo: Repo, cfg: Settings):
    if not await only_admin(ev, client, cfg):
        return await ev.reply("Perintah ini khusus admin.")
    args = parse_args(ev.raw_text)
    if not args:
        return await ev.reply("Gunakan: /welcome on|off | /welcome template <teks> | /welcome preview")
    gc = await repo.get_or_create_group(ev.chat_id)
    if args[0].lower() == "on":
        gc.welcome_enabled = True
        await repo.save_group(gc)
        return await ev.reply("Auto-welcome ON.")
    if args[0].lower() == "off":
        gc.welcome_enabled = False
        await repo.save_group(gc)
        return await ev.reply("Auto-welcome OFF.")
    if args[0].lower() == "template":
        tpl = " ".join(args[1:]).strip()
        if not tpl:
            return await ev.reply("Sertakan template.")
        if len(tpl) > 2000:
            return await ev.reply("Template terlalu panjang (maks 2000).")
        gc.welcome_template = tpl
        await repo.save_group(gc)
        return await ev.reply("Template disimpan.")
    if args[0].lower() == "preview":
        me = await ev.get_sender()
        from .welcome import render_template
        text = render_template(gc.welcome_template, me, None, gc.gate_target)
        return await ev.reply(text)
    return await ev.reply("Argumen tidak dikenali.")


COMMAND_HANDLERS = {
    "help": cmd_help,
    "settings": cmd_settings,
    "gate": cmd_gate,
    "forbidden": cmd_forbidden,
    "spam": cmd_spam,
    "mute": cmd_mute,
    "kick": cmd_kick,
    "logs": cmd_logs,
    "export": cmd_export,
    "import": cmd_import,
    "welcome": cmd_welcome,
}