from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Optional

from telethon import TelegramClient, events
from telethon.tl.functions.channels import EditBannedRequest
from telethon.tl.types import ChatBannedRights

from sqlalchemy.ext.asyncio import AsyncSession

from ..db.repo import Repo
from ..db.models import GateMode, GroupConfig
from ..services.membership import is_member_of
from ..services.logging_svc import log_action
from ..config import Settings

log = logging.getLogger(__name__)

# Simple in-memory booleans for gate throttling (user-> last DM) to avoid DM flood
_last_dm_ts: dict[tuple[int, int], float] = {}  # (chat_id, user_id) -> epoch


async def enforce_gate(
    client: TelegramClient,
    db: AsyncSession,
    cfg: Settings,
    group: GroupConfig,
    chat_id: int,
    user_id: int,
    message_id: Optional[int],
    user_first: str,
) -> bool:
    """
    Returns True if message should be deleted (violates gate).
    """
    if group.gate_mode == GateMode.off:
        return False

    # grace period based on group creation time
    from datetime import timedelta, datetime
    grace_until = (group.created_at or datetime.utcnow()) + timedelta(minutes=cfg.GATE_DEFAULT_GRACE_MIN)
    if datetime.utcnow() < grace_until:
        return False

    ok, hint = await is_member_of(client, user_id, group.gate_target or "")
    if ok:
        # mark verified for this chat
        await Repo(db).set_join_verified(chat_id, user_id)
        return False

    # Not member → try delete message (if perms), DM user join button
    try:
        perms = await Repo(db).get_or_create_group(chat_id)  # reuse for existence
    except Exception:
        pass

    # Delete original message (best-effort)
    try:
        await client.delete_messages(chat_id, [message_id])
    except Exception as e:
        log.debug("delete failed: %s", e)

    # Rate-limit DM
    key = (chat_id, user_id)
    now = time.time()
    if _last_dm_ts.get(key, 0) + 30 < now:  # 30s
        _last_dm_ts[key] = now
        try:
            text = (
                f"Hai {user_first},\n"
                f"Grup ini mewajibkan kamu bergabung ke **{group.gate_mode.value}**: {group.gate_target}\n\n"
                f"Setelah join, tekan /start verify di DM ini untuk verifikasi ulang.\n\n"
                f"_Catatan:_ {hint}"
            )
            await client.send_message(user_id, text, link_preview=False)
            await log_action(db, chat_id, user_id, "gate_dm", "not-member", message_id)
        except Exception as e:
            log.debug("Cannot DM user: %s", e)
    return True


async def recheck_gate_after_dm(
    client: TelegramClient, db: AsyncSession, cfg: Settings, chat_id: int, user_id: int
) -> bool:
    group = await Repo(db).get_group(chat_id)
    if not group or group.gate_mode == GateMode.off:
        return True
    ok, _ = await is_member_of(client, user_id, group.gate_target or "")
    if ok:
        await Repo(db).set_join_verified(chat_id, user_id)
    return ok