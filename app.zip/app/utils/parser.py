from __future__ import annotations

import re
from datetime import timedelta


_duration_re = re.compile(r"(?i)^\s*(\d+)\s*([smhdw]?)\s*$")


def parse_duration(s: str) -> timedelta:
    """
    Parse "10m", "2h", "1d", "30s", "1w".
    Default unit: minutes (if none).
    """
    m = _duration_re.match(s.strip())
    if not m:
        raise ValueError("Durasi tidak valid. Gunakan format seperti 10m, 2h, 1d.")
    val = int(m.group(1))
    unit = (m.group(2) or "m").lower()
    if unit == "s":
        return timedelta(seconds=val)
    if unit == "m":
        return timedelta(minutes=val)
    if unit == "h":
        return timedelta(hours=val)
    if unit == "d":
        return timedelta(days=val)
    if unit == "w":
        return timedelta(days=7 * val)
    raise ValueError("Durasi tidak valid")


def parse_spam_action(s: str) -> str:
    s = s.strip().lower()
    if s == "delete":
        return s
    if s.startswith("mute:"):
        # validate duration
        _ = parse_duration(s.split(":", 1)[1])
        return s
    if s == "kick":
        return s
    raise ValueError("Aksi spam tidak valid. Gunakan delete|mute:<durasi>|kick")