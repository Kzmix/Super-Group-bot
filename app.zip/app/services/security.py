from __future__ import annotations

import asyncio
import logging
import time
from typing import Dict, Tuple

from telethon.tl.functions.channels import GetParticipantRequest, GetParticipantsRequest
from telethon.tl.types import ChannelParticipantsAdmins, ChatParticipantAdmin, ChatParticipantCreator, ChannelParticipantAdmin, ChannelParticipantCreator
from telethon import TelegramClient

log = logging.getLogger(__name__)

# In-memory admin cache: {(chat_id): (set(user_ids), expires_at)}
_admin_cache: Dict[int, Tuple[set[int], float]] = {}


async def refresh_admins(client: TelegramClient, chat_id: int) -> set[int]:
    try:
        admins = set()
        async for p in client.iter_participants(chat_id, filter=ChannelParticipantsAdmins()):
            admins.add(p.id)
        _admin_cache[chat_id] = (admins, time.time() + 90.0)  # 90s TTL
        return admins
    except Exception as e:
        log.warning("refresh_admins failed: %s", e)
        return set()


async def is_admin(client: TelegramClient, chat_id: int, user_id: int) -> bool:
    now = time.time()
    cached = _admin_cache.get(chat_id)
    ids = set()
    if cached and cached[1] > now:
        ids = cached[0]
    else:
        ids = await refresh_admins(client, chat_id)
    return user_id in ids


async def bot_has_perms(client: TelegramClient, chat_id: int) -> dict[str, bool]:
    """
    Return dict of capabilities: delete, restrict, ban
    """
    result = {"delete": False, "restrict": False, "ban": False}
    try:
        me = await client.get_me()
        participant = await client(GetParticipantRequest(chat_id, me.id))
        p = participant.participant
        # Telethon returns different classes for admin rights
        is_admin = isinstance(p, (ChatParticipantAdmin, ChatParticipantCreator, ChannelParticipantAdmin, ChannelParticipantCreator))
        if is_admin:
            # Admin assumed to have rights; fine-grained checks omitted for brevity
            result = {"delete": True, "restrict": True, "ban": True}
    except Exception as e:
        log.warning("bot_has_perms error: %s", e)
    return result