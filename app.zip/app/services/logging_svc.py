from __future__ import annotations
import logging
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from ..db.repo import Repo

log = logging.getLogger(__name__)


async def log_action(session: AsyncSession, chat_id: int, user_id: int, action: str, reason: Optional[str], message_id: Optional[int]) -> None:
    try:
        await Repo(session).add_log(chat_id, user_id, action, reason, message_id)
    except Exception as e:
        log.warning("Failed to log action: %s", e)