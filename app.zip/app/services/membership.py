from __future__ import annotations

import logging
from typing import Optional, Tuple

from telethon import TelegramClient
from telethon.tl.functions.channels import GetParticipantRequest
from telethon.tl.types import Channel, Chat, InputPeerChannel

log = logging.getLogger(__name__)


async def resolve_entity(client: TelegramClient, target: str):
    """
    Resolve @username or t.me link to entity.
    """
    try:
        ent = await client.get_entity(target)
        return ent
    except Exception as e:
        log.warning("resolve_entity failed for %s: %s", target, e)
        return None


async def is_member_of(client: TelegramClient, user_id: int, target: str) -> Tuple[bool, str]:
    """
    Checks if user_id is member of target channel/group.
    Returns (is_member, hint_text).
    For private channels where bot isn't admin, we cannot check reliably.
    """
    entity = await resolve_entity(client, target)
    if not entity:
        return False, "Target tidak valid atau bot tidak bisa resolve (mungkin privat)."

    try:
        res = await client(GetParticipantRequest(entity, user_id))
        # If not exception, found participant → treat as member
        return True, "OK"
    except Exception as e:
        # Not participant or no access
        msg = str(e).lower()
        if "user not participant" in msg:
            return False, "Kamu belum join ke target."
        if "channel private" in msg or "you have no rights" in msg or "peer_id_invalid" in msg:
            return False, "Target privat. Disarankan jadikan bot admin di channel/grup target agar bisa verifikasi."
        return False, "Tidak bisa verifikasi membership saat ini."