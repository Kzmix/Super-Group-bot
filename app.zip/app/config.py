from __future__ import annotations

import logging
from pydantic import BaseSettings, AnyUrl, validator
from typing import List, Optional


class Settings(BaseSettings):
    # Telegram
    BOT_TOKEN: Optional[str] = None  # preferred
    API_ID: Optional[int] = None     # required by Telethon (bot/userbot)
    API_HASH: Optional[str] = None   # required by Telethon (bot/userbot)
    SESSION_NAME: str = "bot.session"  # userbot session/local session filename

    # App
    DATABASE_URL: str = "sqlite+aiosqlite:///./data.db"
    OWNER_IDS: str = ""  # CSV of owner user IDs (optional)
    BASE_URL: Optional[AnyUrl] = None  # optional, for healthcheck/docs
    WEBHOOK_SECRET: Optional[str] = None  # optional endpoint /webhook/<secret>
    LOG_LEVEL: str = "INFO"

    # Anti-spam defaults
    SPAM_WINDOW_SECONDS: int = 7
    DEFAULT_SPAM_THRESHOLD: int = 8
    DEFAULT_SPAM_ACTION: str = "delete"  # delete|mute:10m|kick

    # Gate grace (minutes) after group first seen
    GATE_DEFAULT_GRACE_MIN: int = 15

    class Config:
        env_file = ".env"
        case_sensitive = True

    @property
    def owner_ids(self) -> List[int]:
        if not self.OWNER_IDS.strip():
            return []
        return [int(x) for x in self.OWNER_IDS.split(",") if x.strip().isdigit()]

    @validator("LOG_LEVEL")
    def _validate_level(cls, v: str) -> str:
        level = v.upper()
        if level not in {"DEBUG", "INFO", "WARNING", "ERROR"}:
            return "INFO"
        return level


def setup_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level),
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )