from __future__ import annotations
from datetime import datetime
from sqlalchemy import (
    Column, Integer, BigInteger, String, Text, JSON, Enum, Boolean, DateTime
)
from sqlalchemy.orm import declarative_mixin
from .base import Base
import enum


class GateMode(str, enum.Enum):
    off = "off"
    channel = "channel"
    group = "group"


@declarative_mixin
class TimestampMixin:
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class GroupConfig(Base, TimestampMixin):
    __tablename__ = "group_configs"

    chat_id = Column(BigInteger, primary_key=True, autoincrement=False)
    gate_mode = Column(Enum(GateMode), nullable=False, default=GateMode.off)
    gate_target = Column(String(255), nullable=True)  # @username or join link
    spam_threshold = Column(Integer, nullable=False, default=8)
    spam_action = Column(String(32), nullable=False, default="delete")  # delete|mute:10m|kick
    forbidden_raw = Column(JSON, nullable=False, default=list)  # list[str|/regex/]
    welcome_enabled = Column(Boolean, nullable=False, default=False)
    welcome_template = Column(Text, nullable=False, default="Selamat datang {first_name}!")
    # Privacy-first; no message content retention


class ModerationLog(Base):
    __tablename__ = "moderation_logs"

    id = Column(Integer, primary_key=True)
    chat_id = Column(BigInteger, index=True, nullable=False)
    user_id = Column(BigInteger, index=True, nullable=False)
    action = Column(String(32), nullable=False)  # delete|mute|kick|gate_dm|warn|export|import
    reason = Column(String(255), nullable=True)  # short description or hash
    message_id = Column(BigInteger, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class UserState(Base):
    __tablename__ = "user_states"

    chat_id = Column(BigInteger, primary_key=True, autoincrement=False)
    user_id = Column(BigInteger, primary_key=True, autoincrement=False)

    # Transient counters persisted lightly
    msg_count_window = Column(Integer, nullable=False, default=0)
    last_msg_ts = Column(BigInteger, nullable=False, default=0)  # epoch seconds
    join_verified_at = Column(DateTime, nullable=True)