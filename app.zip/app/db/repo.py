from __future__ import annotations

import asyncio
import hashlib
import logging
from typing import List, Optional, Tuple

from sqlalchemy import select, update, delete, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from .models import GroupConfig, ModerationLog, UserState, GateMode

log = logging.getLogger(__name__)


class Repo:
    def __init__(self, session: AsyncSession):
        self.session = session

    # GroupConfig
    async def get_or_create_group(self, chat_id: int) -> GroupConfig:
        res = await self.session.execute(select(GroupConfig).where(GroupConfig.chat_id == chat_id))
        row = res.scalar_one_or_none()
        if row:
            return row
        gc = GroupConfig(chat_id=chat_id)
        self.session.add(gc)
        await self.session.commit()
        return gc

    async def get_group(self, chat_id: int) -> Optional[GroupConfig]:
        res = await self.session.execute(select(GroupConfig).where(GroupConfig.chat_id == chat_id))
        return res.scalar_one_or_none()

    async def save_group(self, cfg: GroupConfig) -> None:
        self.session.add(cfg)
        await self.session.commit()

    # Forbidden words
    async def add_forbidden(self, chat_id: int, token: str) -> List[str]:
        st = await self.get_or_create_group(chat_id)
        items = list(st.forbidden_raw or [])
        if token not in items:
            items.append(token)
        st.forbidden_raw = items
        await self.save_group(st)
        return items

    async def remove_forbidden(self, chat_id: int, token: str) -> List[str]:
        st = await self.get_or_create_group(chat_id)
        items = [x for x in (st.forbidden_raw or []) if x != token]
        st.forbidden_raw = items
        await self.save_group(st)
        return items

    # UserState (light persistence)
    async def get_user_state(self, chat_id: int, user_id: int) -> UserState:
        res = await self.session.execute(
            select(UserState).where(UserState.chat_id == chat_id, UserState.user_id == user_id)
        )
        row = res.scalar_one_or_none()
        if row:
            return row
        us = UserState(chat_id=chat_id, user_id=user_id)
        self.session.add(us)
        await self.session.commit()
        return us

    async def update_user_window(self, chat_id: int, user_id: int, count: int, ts: int) -> None:
        st = await self.get_user_state(chat_id, user_id)
        st.msg_count_window = count
        st.last_msg_ts = ts
        self.session.add(st)
        await self.session.commit()

    async def set_join_verified(self, chat_id: int, user_id: int) -> None:
        st = await self.get_user_state(chat_id, user_id)
        from datetime import datetime
        st.join_verified_at = datetime.utcnow()
        self.session.add(st)
        await self.session.commit()

    # Logs
    async def add_log(self, chat_id: int, user_id: int, action: str, reason: Optional[str], message_id: Optional[int]) -> None:
        self.session.add(ModerationLog(chat_id=chat_id, user_id=user_id, action=action, reason=reason, message_id=message_id))
        await self.session.commit()

    async def last_logs(self, chat_id: int, limit: int = 10) -> List[ModerationLog]:
        res = await self.session.execute(
            select(ModerationLog).where(ModerationLog.chat_id == chat_id).order_by(desc(ModerationLog.id)).limit(limit)
        )
        return list(res.scalars())

    # Utilities
    @staticmethod
    def tiny_hash(text: str) -> str:
        h = hashlib.sha256(text.encode("utf-8")).hexdigest()
        return h[:10]