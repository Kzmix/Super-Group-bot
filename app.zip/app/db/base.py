from __future__ import annotations

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker, declarative_base
from . import models  # noqa: F401  (import to register models)
from ..config import Settings

Base = declarative_base()


def make_engine(cfg: Settings):
    engine = create_async_engine(cfg.DATABASE_URL, future=True, echo=False)
    return engine


def make_session_factory(engine):
    return sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)